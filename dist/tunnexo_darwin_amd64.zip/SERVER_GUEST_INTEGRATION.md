# Tunnexo guest access — backend integration contract

## Scope and deployment status

The agent implements the contract below. The backend must implement and deploy it before automatic guest connections work. This document specifies a new API; it does not claim the endpoint already exists.

Current scope: anonymous free guest sessions. No signup, payment, account login, refresh token, or permanent installation identity. Each CLI start without an explicit token requests a fresh guest session. Credentials exist only in process memory and disappear when the process exits.

## User flow

```sh
tunnexo agent --target http://localhost:4000
```

1. Agent validates configuration and detects its local IP.
2. If an explicit environment/optional `.env` token exists, existing authentication is used.
3. Otherwise, agent calls `POST https://tunnexo.live/api/v1/agent/guest` over HTTPS.
4. Backend creates a restricted guest principal and issues a cryptographically random token.
5. Agent keeps that token in memory, then connects to Socket.IO namespace `/tunnel` with `auth.token`, `auth.agentName`, and `auth.agentIp`.
6. Server verifies the token and emits `authenticated` with `{ "ok": true }`.
7. Agent emits `tunnel:create` with `{ "name": "localhost" }` and expects an acknowledgement.
8. Server creates a guest-owned tunnel and acknowledges `{ "ok": true, "url": "https://example.tunnexo.live" }`.
9. Agent displays connection status and the public URL. Credentials and raw payloads are never displayed by application logging.
10. Ctrl+C disconnects. Backend cleans up the connection's tunnels. Restart requests a fresh guest token.

## 1. Registration endpoint — exact client contract

**Method/path:** `POST /api/v1/agent/guest` on the same HTTPS origin as the configured Socket.IO server. The HTTP endpoint is not under `/tunnel`. Redirects are not followed.

**Authentication:** None; this is the public guest bootstrap endpoint.

**Request headers:** `Content-Type: application/json`, `Accept: application/json`.

**Request body:**

```json
{
  "platform": "darwin",
  "architecture": "arm64"
}
```

Platform/architecture are informational, untrusted metadata. Do not use them as identity, authorization, or billing facts.

**Success:** HTTP `201 Created`, JSON body, `Cache-Control: no-store`:

```json
{
  "token": "<opaque cryptographically random guest token>",
  "expiresAt": "2026-10-01T12:00:00Z",
  "guestId": "<server generated opaque guest ID>"
}
```

The sample timestamp is illustrative; generate a future timestamp per request. Client requires `token` and RFC3339 `expiresAt`, tolerates extra fields, and currently ignores `guestId`. Token must be 32–4096 characters without spaces/tabs/newlines; generate at least 32 random bytes and encode with base64url. Expiry must be more than 60 seconds in the future when received. Keep response under 16 KiB. Client timeout is 15 seconds.

**Errors:**

| Status | Meaning / agent behavior |
| --- | --- |
| 403 | Guest access disabled or denied; stop with generic error. |
| 429 | Registration limit reached; stop and tell user to try later. No automatic retry loop. |
| 404 / 405 | Endpoint not deployed; actionable server-deployment error. |
| Other non-201 | Stop with status code only; body never printed. |
| Invalid JSON/token/expiry | Stop with generic invalid-response error. |

Never return credentials in error messages. No shared public master token. Do not issue a token with admin scopes.

## 2. Data model

Adapt names to the existing database:

- `principals`: `id`, `kind` (`guest` now), nullable `account_id` for future linking, `created_at`, `disabled_at`.
- `guest_sessions`: `id`, `principal_id`, `token_hash`, `expires_at`, `revoked_at`, `created_at`.
- Existing tunnels: add/enforce `owner_principal_id`, `session_id`, connection ownership, and lifecycle timestamps.
- Usage/rate-limit records: enforce guest quotas across concurrent backend instances.

Store only a cryptographic token hash (for example SHA-256 of the high-entropy opaque token), never the raw token. Return the raw token only in the successful HTTPS registration response. Use secure random generation and constant-time hash comparisons where comparisons happen in application code. Expired records need scheduled cleanup.

## 3. Socket.IO authentication and expiry

- Validate `auth.token` against the token hash, expiry, revocation, and principal state before admitting namespace `/tunnel`.
- Preserve existing explicitly configured token authentication if needed; authorize both flows with clear scopes.
- Bind the resolved principal/session to server-side socket state. Never trust a client-provided owner/guest ID or agent name for authorization.
- Emit `authenticated: {"ok": true}` only after validation; on failure disconnect and return a generic reason.
- Keep tokens out of Socket.IO event/ack payloads, URLs, rooms visible to clients, and logs.
- Recommended initial guest token/session lifetime: 24 hours, enforced by the server. This is a product setting, not a client constant.
- At expiry or revocation, disconnect the socket and close its tunnels. Reconnect must reject expired tokens.
- This client has no automatic renewal: user restarts the command for a new guest session. Do not advertise permanent/background sessions.

## 4. Authorization and public routing

- Guest can create/use/close only its own tunnels.
- Validate ownership for every tunnel operation and `http:response`; require the responding socket to own the pending request and tunnel.
- Assign subdomains on the server. Configure wildcard DNS and TLS for `*.tunnexo.live`.
- Return an HTTPS public URL without userinfo, query parameters, fragment, or non-root path. Current client displays only hosts ending in `.tunnexo.live`.
- Existing HTTP forwarding events (`http:request`, `http:response`) remain unchanged.
- Close or reclaim tunnels on disconnect; define a bounded reconnect grace period if supported.

## 5. Limits and abuse controls

Implement shared, atomic limits before public deployment:

- Registration limits per trusted source IP/network and global issuance capacity. Honor forwarded IP headers only from trusted proxies.
- Active-tunnel/concurrent-connection limits per guest/session and additional network/global limits.
- Bandwidth, request-rate, body-size, pending-request, and request-timeout limits.
- Revocation and operational guest-access disable switch.
- Repeated fresh registrations must not reset all effective abuse limits: this client creates a fresh session each launch, so guest-ID-only quotas are insufficient.

Choose numeric quotas for current infrastructure. Do not require client payment/account flows in this phase.

## 6. Credential logging requirements

Redact authorization headers, cookies, Socket.IO handshake auth, registration response bodies, and tokens in APM/error tracing, reverse proxy logs, and application logs. Do not log full request URLs that can contain credentials. Log event type, internal session ID, result/status, and safe aggregate metrics instead. Do not enable raw Socket.IO transport debugging in public builds.

Agent-side errors use fixed text/status codes; remote response bodies, raw socket errors, request IDs/URLs, and credentials are not printed. The guest token is not written to `.env` or a credentials file.

## 7. Future accounts and paid plans — no implementation now

Keep principal identity separate from entitlement/plan records. Later add authenticated account linking with proof of guest ownership, account sessions, and plan-based limits. A guest ID alone must never prove ownership. Session-only guests in this version have no recovery after process exit; adding persistent device credentials needs a separate client/API version. No payment fields or fake paid status should be added to this bootstrap request.

## 8. Backend acceptance checklist

- Fresh CLI without `.env` obtains a guest token and creates a reachable public tunnel.
- Repeated CLI start creates independent guest sessions.
- Existing explicit token still works.
- Missing/malformed/expired/revoked token is rejected by `/tunnel`.
- Guest A cannot mutate Guest B's tunnel or answer its requests.
- Rate limits are atomic across replicas and survive fresh guest registration.
- Disconnect/expiry cleans up resources.
- Errors and successful connections never expose credentials in terminal or server logs.
- 429, 403, missing endpoint, TLS failure and malformed JSON produce bounded failures.
- End-to-end HTTP request through `https://<subdomain>.tunnexo.live` returns the local application's response.

**Handoff:** Implement this endpoint and namespace authorization in the backend, deploy them at `tunnexo.live`, then run the acceptance checklist with the updated agent. Agent-side mocked registration tests do not establish production readiness.
